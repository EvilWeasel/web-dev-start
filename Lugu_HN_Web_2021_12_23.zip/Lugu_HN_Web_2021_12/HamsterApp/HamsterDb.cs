﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace HamsterApp
{

    public class HamsterDb : IDisposable

    {
        private string strCon = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=HamsterDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        private SqlConnection Connection { get; set; }

        public HamsterDb()
        {
            Connection = new SqlConnection(strCon);
        }
        public IEnumerable<Hamster> GetHamster()
        {

            Connection.Open();
            SqlCommand c = new SqlCommand();
            c.Connection = Connection;
            Hamster.CreateSqlSelectCommand(c);
            SqlDataReader reader = c.ExecuteReader();
            //foreach (var x in reader)
            //{
            //}
            while (reader.Read())
            {
                //Hamster h = new Hamster();
                //h.Id = (int)reader["Id"];
                //h.Name = reader["Name"] as string;
                //h.Farbe = (Farbe)reader["Farbe"];
                //h.Geschlecht = (Geschlecht)reader["Geschlecht"];
                //h.Alter = reader.GetInt32(3);
                yield return Hamster.CreateHamster(reader);
            }
            reader.Close();
            Connection?.Close();
        }
        public bool InsertHamster(Hamster h)
        {
            try
            {
                Connection.Open();
                SqlCommand c = new SqlCommand();
                c.Connection = Connection;
                h.CreateSqlInsertCommand(c);
                c.ExecuteNonQuery();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                Connection?.Close();
            }
        }

        public bool DeleteHamster(int id)
        {
            try
            {
                Connection.Open();
                SqlCommand c = new SqlCommand();
                c.Connection = Connection;
                Hamster.CreateSqlDeleteCommand(c, id);
                c.ExecuteNonQuery();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                Connection?.Close();
            }
        }

        public void Dispose()
        {
            Connection?.Dispose();
        }
    }
}