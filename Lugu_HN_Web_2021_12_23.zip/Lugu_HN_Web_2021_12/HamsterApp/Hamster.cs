﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
 

namespace HamsterApp
{
    public enum Geschlecht { Unbekannt, Weiblich, Männlich}
    public enum Farbe { Blau, Grün, Rot, Braun, Schwarz, Gelb, Orange}
    public class Hamster
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Farbe Farbe { get; set; }
        public Geschlecht Geschlecht { get; set; }
        public int Alter { get; set; }
        public override string ToString()
        {
            return string.Format("Id:{0} Name:{1} Farbe:{2} Alter:{3} Geschlecht:{4}", Id, Name, Farbe, Alter,Geschlecht);
        }
        public void CreateSqlInsertCommand(SqlCommand cmd)
        {
            string sql = @"insert into tblHamster(Name, Farbe, [Alter], Geschlecht) values(@Name, @Farbe, @Alter, @Geschlecht)";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@Name",Name);
            cmd.Parameters.AddWithValue("@Farbe", Farbe);
            cmd.Parameters.AddWithValue("@Alter", Alter);
            cmd.Parameters.AddWithValue("@Geschlecht", Geschlecht);
        }

        public static void CreateSqlDeleteCommand(SqlCommand cmd, int id)
        {
            string sql = @"delete from tblHamster where Id = @Id";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@Id", id);
        }

        public static void CreateSqlSelectCommand(SqlCommand cmd)
        {
            string sql = @"select Id, Name, Farbe, [Alter], Geschlecht from tblHamster";
            cmd.CommandText = sql;
        }

        public static Hamster CreateHamster(SqlDataReader reader)
        {
            Hamster h = new Hamster();
            h.Id = (int)reader["Id"];
            h.Name = reader["Name"] as string;
            h.Farbe = (Farbe)reader["Farbe"];
            h.Geschlecht = (Geschlecht)reader["Geschlecht"];
            h.Alter = reader.GetInt32(3);
            return h;
        }

    }


}