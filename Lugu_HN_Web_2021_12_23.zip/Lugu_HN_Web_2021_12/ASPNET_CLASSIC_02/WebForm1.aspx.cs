﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASPNET_CLASSIC_02
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                TEXT001.InnerHtml = "DAS IST EIN HTML-ELEMENT";
                DropDownList1.Items.Add("+");
                DropDownList1.Items.Add("-");
                DropDownList1.Items.Add("*");
                DropDownList1.Items.Add("/");
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int z1 = int.Parse(TextBox1.Text);
            int z2 = int.Parse(TextBox2.Text);
            int res=0;
            switch (DropDownList1.SelectedValue)
            {
                case "+":
                    res = z1 + z2;
                    break;
                case "-":
                    res = z1 - z2;

                    break;
                case "*":
                    res = z1 * z2;

                    break;
                case "/":
                    res = z1 / z2;

                    break;
                default:
                    break;
            }
            TextBox3.Text = res.ToString();
        }
    }
}