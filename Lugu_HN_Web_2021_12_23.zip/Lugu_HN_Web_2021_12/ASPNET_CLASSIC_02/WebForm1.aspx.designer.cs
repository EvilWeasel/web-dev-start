﻿//------------------------------------------------------------------------------
// <automatisch generiert>
//     Dieser Code wurde von einem Tool generiert.
//
//     Änderungen an dieser Datei können fehlerhaftes Verhalten verursachen und gehen verloren, wenn
//     der Code neu generiert wird.
// </automatisch generiert>
//------------------------------------------------------------------------------

namespace ASPNET_CLASSIC_02
{


    public partial class WebForm1
    {

        /// <summary>
        /// form1-Steuerelement.
        /// </summary>
        /// <remarks>
        /// Automatisch generiertes Feld.
        /// Zum Ändern Felddeklaration aus der Designerdatei in eine Code-Behind-Datei verschieben.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;

        /// <summary>
        /// TEXT001-Steuerelement.
        /// </summary>
        /// <remarks>
        /// Automatisch generiertes Feld.
        /// Zum Ändern Felddeklaration aus der Designerdatei in eine Code-Behind-Datei verschieben.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlGenericControl TEXT001;

        /// <summary>
        /// Button1-Steuerelement.
        /// </summary>
        /// <remarks>
        /// Automatisch generiertes Feld.
        /// Zum Ändern Felddeklaration aus der Designerdatei in eine Code-Behind-Datei verschieben.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button Button1;

        /// <summary>
        /// TextBox1-Steuerelement.
        /// </summary>
        /// <remarks>
        /// Automatisch generiertes Feld.
        /// Zum Ändern Felddeklaration aus der Designerdatei in eine Code-Behind-Datei verschieben.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox TextBox1;

        /// <summary>
        /// DropDownList1-Steuerelement.
        /// </summary>
        /// <remarks>
        /// Automatisch generiertes Feld.
        /// Zum Ändern Felddeklaration aus der Designerdatei in eine Code-Behind-Datei verschieben.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList DropDownList1;

        /// <summary>
        /// TextBox2-Steuerelement.
        /// </summary>
        /// <remarks>
        /// Automatisch generiertes Feld.
        /// Zum Ändern Felddeklaration aus der Designerdatei in eine Code-Behind-Datei verschieben.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox TextBox2;

        /// <summary>
        /// TextBox3-Steuerelement.
        /// </summary>
        /// <remarks>
        /// Automatisch generiertes Feld.
        /// Zum Ändern Felddeklaration aus der Designerdatei in eine Code-Behind-Datei verschieben.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox TextBox3;

        /// <summary>
        /// SqlDataSource1-Steuerelement.
        /// </summary>
        /// <remarks>
        /// Automatisch generiertes Feld.
        /// Zum Ändern Felddeklaration aus der Designerdatei in eine Code-Behind-Datei verschieben.
        /// </remarks>
        protected global::System.Web.UI.WebControls.SqlDataSource SqlDataSource1;

        /// <summary>
        /// GridView1-Steuerelement.
        /// </summary>
        /// <remarks>
        /// Automatisch generiertes Feld.
        /// Zum Ändern Felddeklaration aus der Designerdatei in eine Code-Behind-Datei verschieben.
        /// </remarks>
        protected global::System.Web.UI.WebControls.GridView GridView1;
    }
}
