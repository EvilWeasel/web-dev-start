﻿var MyModule = (function () {
    function _help01() {

    }

    function writevar(a) {
        console.log("a:" + a + ", " + typeof (a))
    }
    var dummy = { "Name": "Winfried", "Farbe": "Grün" }
    return {
        "consolelog": writevar,
        "winfried": { "Name": "Winfried", "Farbe": "Grün" },
        "minischterbräääääsideeeeend" : dummy
    }
})()

