﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JS001
{
     
    public class Hamster
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Farbe { get; set; }
        public string Geschlecht { get; set; }
        public int Alter { get; set; }

    }


    public class HamsterRepository
    {
        public static IEnumerable<Hamster> GetHamster()
        {
            yield return new Hamster() { Id = 1, Name = "Horst", Alter = 99, Farbe = "rot", Geschlecht = "m" };
            yield return new Hamster() { Id = 2, Name = "Winfried", Alter = 722, Farbe = "grün", Geschlecht = "m" };
            yield return new Hamster() { Id = 3, Name = "Dieter", Alter = 152, Farbe = "weiss", Geschlecht = "m" };
            yield return new Hamster() { Id = 4, Name = "Angela", Alter = 212, Farbe = "orange", Geschlecht = "w" };
            yield return new Hamster() { Id = 5, Name = "Uschi", Alter = 121, Farbe = "schwarz", Geschlecht = "w" };
        }

    }
}